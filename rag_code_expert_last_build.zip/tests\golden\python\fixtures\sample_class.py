"""Module docstring: battle engine sample for the Python chunker golden."""
import math
from typing import Optional

DEFAULT_MALUS = 10
MAX_TROOPS = 1000


class BattleEngine(Combatant):
    """Orchestrates a long-running battle (exercises class split into methods)."""

    rounds: int = 0

    def __init__(self, engine_id: str, attacker: str) -> None:
        self.id = engine_id
        self.attacker = attacker
        self.rounds = 0

    def run_round(self, troops_a: int, troops_b: int) -> int:
        self.rounds += 1
        malus = self._compute_malus(troops_a, troops_b)
        survivors = troops_a - troops_b - malus
        if survivors < 0:
            survivors = 0
        for _ in range(self.rounds):
            survivors = max(0, survivors - 1)
        return survivors

    def _compute_malus(self, a: int, b: int) -> int:
        ratio = 0 if a == 0 else b / a
        if ratio > 2:
            return 80
        elif ratio > 1:
            return 40
        return DEFAULT_MALUS

    def resolve(self, troops_a: int, troops_b: int) -> str:
        a, b = troops_a, troops_b
        while a > 0 and b > 0:
            a = self.run_round(a, b)
            b = self.run_round(b, a)
        return self.attacker if a > b else "defender"

    def status_report(self) -> dict:
        report = {
            "engine": self.id,
            "attacker": self.attacker,
            "rounds": self.rounds,
        }
        if self.rounds > 10:
            report["status"] = "long"
        else:
            report["status"] = "short"
        return report

    @property
    def summary(self) -> str:
        return f"engine={self.id} attacker={self.attacker} rounds={self.rounds}"

    def reset(self) -> None:
        self.rounds = 0
