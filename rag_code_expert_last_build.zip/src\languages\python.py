# src/languages/python.py
#
# Provider Python (.py/.pyi). Sprint 2 - Phase 2.
#
# status = EXPERIMENTAL tant que le vertical complet (chunker golden + graphe SCIP
# a parite + revue agent) n'est pas prouve. Le gate REFUSE l'indexation d'un projet
# contenant du code EXPERIMENTAL (au meme titre que non supporte) -> pas de
# pipeline degrade. Passe a VALIDATED en P3 une fois la parite mesuree.
#
# Node-types tree-sitter-python (verifies par introspection de la grammaire) :
#   module/classe : import_statement, import_from_statement, assignment, comment,
#                   decorated_definition, class_definition, function_definition
#   class/func body = champ 'body' (block) -> compatible RecursiveASTSplitter.
#   decorated_definition enveloppe decorator + function_definition (garde le
#   decorateur AVEC la fonction quand le noeud n'est pas re-split).

from __future__ import annotations

from .base import LanguageProvider, ScipIndexerSpec

_MAX_SPLIT_LINES = 50
_MIN_MERGE_LINES = 10

# Noeuds re-decoupables si trop gros (on descend dans leur 'body').
_SPLITTABLE = frozenset({
    "class_definition",
    "function_definition",
    "decorated_definition",
    "if_statement",
    "for_statement",
    "while_statement",
    "try_statement",
    "with_statement",
})
# Noeuds-feuilles chunkes tels quels (puis fusionnes par le merger s'ils sont courts).
_LEAF = frozenset({
    "import_statement",
    "import_from_statement",
    "assignment",            # constantes module / attributs de classe
    "expression_statement",  # docstrings / expressions de module
    "comment",
})
# Noeuds porteurs d'un champ 'name' (class/def). decorated_definition -> nom generique.
_NAME_FIELD = frozenset({
    "class_definition",
    "function_definition",
})

PROVIDER = LanguageProvider(
    name="python",
    extensions=frozenset({".py", ".pyi"}),
    ts_language="python",
    splittable_node_types=_SPLITTABLE,
    leaf_node_types=_LEAF,
    name_field_node_types=_NAME_FIELD,
    max_lines=_MAX_SPLIT_LINES,
    min_lines=_MIN_MERGE_LINES,
    status="VALIDATED",  # Phase 2 P3 : chunker golden + graphe SCIP (Pyright) prouves
    golden_dir="tests/golden/python",
    unwrap_name_node_types=frozenset({"decorated_definition"}),
    scip_indexer=ScipIndexerSpec(
        # L'image indexers est etendue avec scip-python en P2.
        docker_image="code-expert-indexers:latest",
        index_cmd=("scip-python", "index", "--output", "/out/index.scip",
                   "--project-name", "{project}", "--project-version", "HEAD"),
        needs_config="pyrightconfig.json",
    ),
)
