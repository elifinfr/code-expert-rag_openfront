# rag_code_expert_last_build — RAG agentique multi-langage (TS / JS / Python)

**Build du 2026-06-09.** Système RAG quadri-source (Neo4j + Qdrant + Chroma + SQLite)
avec agent ReAct, **multi-langage** : TypeScript, JavaScript et **Python** sont
`VALIDATED` (Python prouvé end-to-end sur le repo `click` de Pallets : graphe
613 nœuds / 1 553 arêtes, 1 089 chunks, 42 fiches, réponses agent sourcées).

## Contenu

| Élément | Rôle |
|---|---|
| `rag.py` / `main.py` | orchestrateur CLI / interface guidée |
| `config.ini` | configuration (endpoints, modèles, `GRAPH_BACKEND`, `CODE_DIRECTORY`) |
| `src/languages/` | registre multi-langage (providers ts/js/**python**, gate) |
| `src/graph_builder/` | backbone graphe SCIP : Dockerfile (scip-typescript **+ scip-python**), runner, loader |
| `src/*.py` | étapes ETL (audit, graph, fiches, chunks, json) + `agent_react.py` |
| `tests/` | test_registry (31), test_gate (20), golden chunker ts/js/**python** (5 fixtures) |
| `GUIDE.md` | installation & utilisation pas-à-pas |
| `DOCUMENTATION_RAG.md` | **fonctionnement interne complet : indexation + agentique** |

## Installation rapide

1. **Python 3.12** : `pip install -r requirements.txt`
2. **Docker Desktop** : `docker compose up -d neo4j` · `docker run -d -p 6333:6333 --name qdrant qdrant/qdrant`
3. **Image indexeurs SCIP** (graphe) :
   `docker build -f src/graph_builder/Dockerfile.indexers -t code-expert-indexers:latest .`
4. **LM Studio** (génération, :1234) : `lms load qwen3-4b-instruct-2507 -c 12288 --parallel 1 --gpu max -y`
5. **Embeddings** (:8090) : llama.cpp `llama-server` (build Vulkan) + GGUF
   `nomic-embed-code.Q4_K_S.gguf` — adapter les chemins dans
   `scripts/start_embed_server.ps1` et `config.ini` (`EMBEDDING_GGUF`).
   *(Les binaires llama.cpp et les GGUF ne sont pas inclus dans le zip.)*
6. Placer le projet à analyser **sous la racine** (ex. `./MonProjet`), pointer
   `CODE_DIRECTORY` dans `config.ini` (ou menu `M` de `main.py`).
7. `python rag.py doctor` → viser 0 échec, puis `python main.py` → option `P`.

## Différences vs la distribution `ts_js`

- Provider **Python** (`src/languages/python.py`, status VALIDATED) + golden Python.
- Image Docker : ajoute **scip-python 0.6.0** (moteur Pyright + python3/pip).
- `scip_runner.run_scip_python` + dispatch par langage primaire du manifest.
- Loader SCIP **language-aware** (Python : pas d'interfaces → héritage `HERITE_DE`).
- Audit **registre-aware** (les extensions admises suivent les providers).
- Résilience fiches : timeout 120 s/fichier, upload Qdrant incrémental,
  reprise `rag.py fiches --resume`.

## Vérification

```
python tests/test_registry.py            # 31/31
python tests/test_gate.py                # 20/20
python tests/golden/run_golden.py --check  # 5/5 (ts, js, python)
python rag.py doctor
```

Voir `DOCUMENTATION_RAG.md` pour le fonctionnement détaillé (pipeline d'indexation,
agent, ajout d'un nouveau langage) et `GUIDE.md` pour l'exploitation quotidienne.
