"""Standalone functions + decorated function (merge + split paths)."""
import functools

MIN_TROOPS = 0
MAX_TROOPS = 1000


def clamp(value, low, high):
    return max(low, min(high, value))


@functools.lru_cache(maxsize=128)
def combine_troops(a_count, b_count, malus):
    """Combine two troop pools with a flat malus.

    Deliberately long (> 10 lines span) so the decorated definition is emitted
    as its own standalone chunk rather than merged with neighbours.
    """
    raw = a_count + b_count - malus
    count = clamp(raw, MIN_TROOPS, MAX_TROOPS)
    morale = (a_count + b_count) // 2
    if count <= MIN_TROOPS:
        count = 0
        morale = 0
    if count > MAX_TROOPS:
        count = MAX_TROOPS
    return {"count": count, "morale": morale}


def is_routed(count, morale):
    return count <= MIN_TROOPS or morale < 5


def _internal_helper(n):
    return n * 2
